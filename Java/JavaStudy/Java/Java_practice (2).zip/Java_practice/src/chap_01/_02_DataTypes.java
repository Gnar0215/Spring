package chap_01;

public class _02_DataTypes {
    public static void main(String[] args) {
        System.out.println("Hello World!!");
        System.out.println("안녕하세요?");
        System.out.println(12);
        System.out.println(-34);
        System.out.println(3.14);
        System.out.println(true);
        System.out.println(false);

        System.out.println(123+456);
    }
}
