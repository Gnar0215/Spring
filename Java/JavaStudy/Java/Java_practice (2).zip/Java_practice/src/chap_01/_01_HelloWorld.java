package chap_01;

public class _01_HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
